﻿namespace TSD.Linq.Cars
{
   
    public class Car
    {
        public string Make { get; private set; }
        public int Sales2015 { get; set; }
        public int Sales2014 { get; set; }
        public int? NumberOfSeats { get; set; } 

        public Car(string make)
        {
            Make = make;
        }
    }
}
