﻿using System;
using System.Collections.Generic;
using System.Linq;
using TSD.Linq.Cars;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            var carSalesBook = new CarSalesBook();

            Console.WriteLine("Task 2.4");
            IEnumerable<Car> top3Makes = carSalesBook.Cars.OrderByDescending(car => car.Sales2015).Take(3);
            foreach (Car car in top3Makes)
            {
                Console.WriteLine(car.Make);
            }
            Console.WriteLine();

            Console.WriteLine("Task 2.5");
            IEnumerable<Car> salesIncreasedMakes = carSalesBook.Cars.Where(car => car.Sales2015 >= 1.5 * car.Sales2014);
            foreach (Car car in salesIncreasedMakes)
            {
                Console.WriteLine(car.Make);
            }
            Console.WriteLine();

            Console.WriteLine("Task 2.6");
            IEnumerable<Car> top3FromSecondTenMakes = carSalesBook.Cars.OrderByDescending(car => car.Sales2015).Take(13).Skip(10);
            foreach (Car car in top3FromSecondTenMakes)
            {
                Console.WriteLine(car.Make);
            }
            Console.WriteLine();
            
            Console.WriteLine("Task 2.7");
            int totalOf2014 = carSalesBook.Cars.Sum(car => car.Sales2014);
            int totalOf2015 = carSalesBook.Cars.Sum(car => car.Sales2015);
            Console.WriteLine(totalOf2014);
            Console.WriteLine(totalOf2015);
            Console.WriteLine();

            Console.WriteLine("Task 2.8");
            IEnumerable<Car> top10Makes = carSalesBook.Cars.OrderByDescending(car => car.Sales2015).Take(10);
            IEnumerable<Car> last10Makes = carSalesBook.Cars.OrderBy(car => car.Sales2015).Take(10);
            IEnumerable<Car> top10AndLast10Makes = top10Makes.Union(last10Makes);
            foreach (Car car in top10AndLast10Makes)
            {
                Console.WriteLine(car.Make);
            }
            Console.WriteLine();

            carSalesBook.WriteCarsToXmlFile();

            foreach (Car car in carSalesBook.ReadCarsFromXmlFile())
            {
                Console.WriteLine("{0}, {1}, {2}, {3}", car.Make, car.Sales2014, car.Sales2015, car.NumberOfSeats ?? 0);
            }

            Console.ReadLine();
        }
    }
}
