﻿using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using ConsoleApplication1;

namespace TSD.Linq.Cars
{
    public class CarSalesBook
    {
        public IList<Car> Cars { get; private set; }

        public CarSalesBook()
        {
            Cars = ReadCarsFromFile();
        }

        private IList<Car> GenerateCars()
        {
            var cars = new List<Car>
            {
                new Car("Skoda") {Sales2014 = 45529, Sales2015 = 44243},
                new Car("Toyota") {Sales2014 = 36465, Sales2015 = 31484},
                new Car("BMW") {Sales2014 = 9549, Sales2015 = 7714}
            };
            
            IList<Car> sortedCars = cars.OrderBy(c => c.Sales2015).ToList();

            //Task 1.6/1.7
            Car myCar = new Car("Toyota") { NumberOfSeats = 5 }; 
            int numOfSeats = myCar.NumberOfSeats ?? default(int);
            return cars;
        }

        private IList<Car> ReadCarsFromFile()
        {
            return CarDataFileReader.ReadCarsFromCSVFile();
        }

        public void WriteCarsToXmlFile()
        {
            XDocument xml = new XDocument(
                new XDeclaration("1.0", "utf-8", "no"),
                new XElement("Makes",
                    from car in Cars
                    select new XElement("Car",
                        new XElement("Make", car.Make),
                        new XElement("Sales2014", car.Sales2014),
                        new XElement("Sales2015", car.Sales2015),
                        new XElement("NumberOfSeats", car.NumberOfSeats ?? 0))
                )
            );

            xml.Save("cars.xml");
        }

        public IEnumerable<Car> ReadCarsFromXmlFile()
        {
            XDocument xml = XDocument.Load("cars.xml");
            IEnumerable<Car> cars =
                from car in xml.Element("Makes").Elements("Car")
                select new Car(car.Element("Make").Value) { Sales2014 = int.Parse(car.Element("Sales2014").Value), Sales2015 = int.Parse(car.Element("Sales2015").Value), NumberOfSeats = int.Parse(car.Element("Sales2015").Value) > 0 ? int.Parse(car.Element("Sales2015").Value) : (int?) null };

            return cars;
        }
    }
}
